#include <stdio.h>

int max_number(int n);
int min_number(int n);

int main()
{
    int n;
    int maxi = 0, mini = 9;
    printf("Input number: ");
    if (scanf("%d", &n) != 1){
        printf("Error");
        return -1;
    }

    maxi = max_number(n);
    mini = min_number(n);

    printf("maximal = %d\nmininal = %d", maxi, mini);

    return 0;

}

int max_number(int n)
{
    int maxim = 0;

    while (n > 0){
        if ((n % 10) > maxim) maxim = n % 10;
        n /= 10;
    }

    return maxim;
}

int min_number(int n)
{
    int minim = 9;

    while (n > 0){
        if ((n % 10) < minim) minim = n % 10;
        n /= 10;
    }

    return minim;
}
