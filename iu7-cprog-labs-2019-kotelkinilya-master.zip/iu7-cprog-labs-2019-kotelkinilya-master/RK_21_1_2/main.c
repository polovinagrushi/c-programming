#include <stdio.h>

int input(int a[], int n);
void output(int a[], int n);
void delete(int a[], int *n, int k);

int main()
{
    //max len = 10
    int a[10];
    int n, k;

    printf("Input len of array: ");
    if (scanf("%d", &n) != 1){
        printf("Error\n");
        return -1;
    }
    else if (n < 1){
        printf("Error\n");
        return -1;
    }
    else if (n > 10){
        printf("Error\n");
        return -1;
    }

    printf("Input k: ");
    if (scanf("%d", &k) != 1){
        printf("Error input\n");
        return -1;
    }

    input(a, n);

    delete(a, &n, k);

    output(a, n);

    return 0;

}

int input(int a[], int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("Input a[%d]: ", i);
        if (scanf("%d", &(a[i])) != 1)
        {
            printf("Error\n");
            return -1;
        }
    }

    return 0;
}

void delete(int a[], int *n, int k)
{
    int count = 0;

    for (int i = 0; i < *n; i++){
        if (a[i] % k == 0){
            count++;
            if (count % 2 == 0){
                for (int j = i; j < *n - 1; j ++)
                    a[j] = a[j+ 1];
                i--;
                (*n)--;
            }
        }
    }
}

void output(int a[], int n)
{
    for (int i = 0; i < n; i++)
        printf("%d ", a[i]);
   printf("\n");
}
