#include <stdio.h>

int remake(int temp, int arr[][temp], int row, int col);
int out(int temp, int arr[][temp]);
int finder(int *max_i, int *max_j, int temp, int arr[][temp]);
int fill(FILE *f, char**argv, int temp, int arr[][temp]);

int main(int argc, char **argv)
{
    int temp;
    int max_i = 0, max_j = 0;
    FILE *f;
    f = fopen(argv[1], "r");
    if (fscanf(f, "%d", &temp) != 1)
    {
        printf("Incorrect input");
        fclose(f);
        return -1;
    }
    int arr[temp][temp];
    if (f == NULL)
    {
        puts("ERROR");
        return -1;
    }
    fclose(f);
    if (fill(f, &*argv, temp, arr) == -1)
        return -1;
    finder(&max_i, &max_j, temp, arr);
    remake(temp, arr, max_i, max_j);
    out(temp, arr);
    return 0;
}

int remake(int temp, int arr[][temp], int row, int col)
{
    int i;
    int j;

    for (i = 0; i < temp - 1 ; i++)
    {
        if (i < row)
        {

            for (j = 0; j < temp - 1; j++)
                if (j >= col)
                    arr[i][j] = arr[i][j + 1];
        }
        else
        {
            for (j = 0; j < temp; j++)
            {
                if (j < col)
                    arr[i][j] = arr[i + 1][j];
                if (j > col)
                    arr[i][j - 1] = arr[i + 1][j];
            }
        }
    }
    return 0;
}

int out(int temp, int arr[][temp])
{
    printf("Matrix: \n");
    for (int i = 0; i < temp - 1; i++)
    {
        for (int j = 0; j < temp - 1; j++)
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
    return 0;
}
int finder(int *max_i, int *max_j, int temp, int arr[][temp])
{
    int max = arr[0][0];
    int i;
    int j;

    for (i = 0; i < temp ; i++ )
    {
        for (j = 0; j < temp; j++ )
        {
            if (arr[i][j] > max)
            {
                max = arr[i][j];
                *max_i = i;
                *max_j = j;
            }
        }
    }
    return 0;
}

int fill(FILE *f, char**argv, int temp, int arr[][temp])
{
    float d, checker;
    int perem;
    int i = 0;
    int j;

    f = fopen(argv[1], "r");

    fscanf(f, "%f", &d);
    perem = d;
    if (perem != d || perem <= 0)
    {
        puts("ERROR");
        return -1;
    }
    for (i = 0; i < temp ; i++ )
    {
        for (j = 0; j < temp; j++ )
        {
            if (fscanf(f, "%f", &checker) != 1)
            {
                printf("Incorrect input");
                fclose(f);
                return -1;
            }
            arr[i][j] = checker;
            if (checker != arr[i][j])
            {
                printf("Incorrect number");
                fclose(f);
                return -1;
            }
         }
    }
    if (temp != i)
    {
        puts("Inccorect number");
        return -1;
    }
    fclose(f);
    return 0;
}
