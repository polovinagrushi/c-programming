#include <stdio.h>
#include <math.h>

int main(void)
{
    float x1, x2, x3;
    float y1, y2, y3;
    float ab, bc, ca;
    float p;

    printf("Input first coordinates: ");
    scanf("%f %f", &x1, &y1);
    printf("Input second coordinates: ");
    scanf("%f %f", &x2, &y2);
    printf("Input third coordinates: ");
    scanf("%f %f", &x3, &y3);

    ab = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    bc = sqrt(pow(x3 - x2, 2) + pow(y3 - y2, 2));
    ca = sqrt(pow(x3 - x1, 2) + pow(y3 - y1, 2));

    p = ab + bc + ca;

    printf("%.5f\n", p);

    return 0;
}
