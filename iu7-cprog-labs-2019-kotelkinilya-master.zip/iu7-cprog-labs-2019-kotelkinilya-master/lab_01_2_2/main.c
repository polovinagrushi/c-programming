#include <stdio.h>
int main()
{
    int s;
    s = 56;
    printf ("Year has %d weeks\n", s);
    return 0;
}
