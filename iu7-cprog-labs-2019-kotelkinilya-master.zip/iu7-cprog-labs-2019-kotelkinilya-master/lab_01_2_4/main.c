#include <stdio.h>

int main()
{
    int s;
    printf("Input value: ");
    scanf("%d", &s);

    int minutes = s / 60;
    int new_s = s - minutes * 60;
    int hour = minutes / 60;
    int new_minutes = minutes - hour * 60;

    printf("%d hour %d minutes %d seconds", hour, new_minutes, new_s);
    return 0;
}
