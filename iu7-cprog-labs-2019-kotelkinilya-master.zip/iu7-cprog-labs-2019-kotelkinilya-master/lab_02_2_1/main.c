#include <stdio.h>
#include <math.h>

int fibbo(int n)
{
    float fn1 = (1 + sqrt(5)) / 2;
    float fn2 = (1 - sqrt(5)) / 2;
    int fn = (pow(fn1, n) - pow(fn2, n)) / sqrt(5);
    return fn;
}

int main(void)
{
    int n, r, f;
    printf("Input n: ");
    f = scanf("%d", &n);
    if (f != 1)
    {
        printf("Неправильный ввод\n");

        return -1;
    }

    if ((n < 0) || (n > 47))
    {
        printf("Неправильный ввод");

        return -1;
    }

    r = fibbo(n);
    printf("F(n) = %d", r);

    return 0;
}
