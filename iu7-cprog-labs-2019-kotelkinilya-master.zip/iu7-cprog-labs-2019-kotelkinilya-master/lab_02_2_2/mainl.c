#include <stdio.h>
#include <math.h>

int treug(float x1, float y1, float x2, float y2, float x3, float y3, float xa, float ya)
{
    float ab = (x1 - xa) * (y2 - y1) - (x2 - x1) * (y1 - ya);
    float bc = (x2 - xa) * (y3 - y2) - (x3 - x2) * (y2 - ya);
    float ca = (x3 - xa) * (y1 - y3) - (x1 - x3) * (y3 - ya);

    if ((ab == 0) || (bc == 0) || (ca == 0))
    {
        printf("1\n");
    }
    else if (((ab > 0) && (bc > 0) && (ca > 0)) || ((ab < 0) && (bc < 0) && (ca < 0)))
    {
        printf("0\n");
    }
    else
    {
        printf("2\n");
    }

    return 0;
}

int existence(float x1, float y1, float x2, float y2, float x3, float y3)
{
    float ab = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    float bc = sqrt(pow(x3 - x2, 2) + pow(y3 - y2, 2));
    float ca = sqrt(pow(x1 - x3, 2) + pow(y1 - y3, 2));
    float p = (ab + bc + ca) / 2;
    float s = sqrt(p * (p - ab) * (p - bc) * (p - ca));

    if (s == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main(void)
{
    float x1, x2, x3;
    float y1, y2, y3;
    float xa, ya;
    int check_exi, k;

    printf("Input first coordinates: ");
    if (scanf("%f%f", &x1, &y1) != 2)
    {
        printf("Error");
        return -1;
    }
    printf("Input second coordinates: ");
    if (scanf("%f%f", &x2, &y2) != 2)
    {
        printf("Error");
        return -1;
    }
    printf("Input third coordinates: ");
    if (scanf("%f%f", &x3, &y3) != 2)
    {
        printf("Error");
        return -1;
    }
    check_exi = existence(x1, y1, x2, y2, x3, y3);
    if (check_exi == 1)
    {
        printf("Triangle does not exist");
        return -1;
    }

    printf("Input dot's coordinate: ");
    if (scanf("%f%f", &xa, &ya) != 2)
    {
        printf("Error");
        return -1;
    }

    k = treug(x1, y1, x2, y2, x3, y3, xa, ya);

    printf("%d", k);
    return 0;
}
