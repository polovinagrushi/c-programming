#include <stdio.h>
#include <math.h>

double s_x(float x, double eps)
{
    int tek = 1;
    double res = x, tmp = x;

    while (fabs(tmp) > fabs(eps))
    {
        tek += 2;
        tmp *= (pow(x, 2) * pow((tek - 2), 2)) / ((tek - 1) * tek);
        res += tmp;
    }

    return res;
}

float f_x(float x)
{
    return asin(x);
}

int main()
{
    float x, eps;
    double s, f, absol, otnos;
    int d;

    printf("Enter x and eps - ");
    d = scanf("%f%f", &x, &eps);

    if (d < 2)
    {
        printf("Incorrect input");

        return -1;
    }
    else
    {
        if (fabs(x) >= 1)
        {
            printf("Incorrect value of x, it should be |x| < 1");

            return -1;
        }
        if (x == 0)
        {
            printf("Incorrect value of x, it shouldn't equals 0");

            return -1;
        }
        if ((eps <= 0) || (eps > 1))
        {
            printf("Epsilon should be in (0, 1]");

            return -1;
        }
        else
        {
            f = f_x(x);
            s = s_x(x, eps);
            absol = fabs(f - s);
            otnos = fabs((f - s) / f);
            printf("Output - %lf %lf %lf %lf", s, f, absol, otnos);

            return 0;
        }
    }
}
