#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int process(FILE* f, float *sum, int *temp);
float macking(FILE *f, float equa);

int main(int argc, char *argv[])
{
    FILE *f;
    int d = 0;
    int temp = 0;
    float sum = 0;
    if (argc != 2)
    {
        fputs("Incorrect input", stderr);
        return -1;
    }
    f = fopen(argv[1], "r");
    if (!f)
    {
        fputs("No such file", stderr);
        return -2;
    }
    
    d = process(f, &sum, &temp);
    if (d == 1)
    {
        fputs("Empty file", stderr);
        return 1;
    }
    
    if (d == 2)
    {
        fputs("Incorrect input", stderr);
        return 2;
    }
    
    float equa = sum / temp, ans;
    
    ans = macking(f, equa);
    
    fclose(f);
    fprintf(stdout, "%.5f", ans);
    
    return 0;
}

int process(FILE* f, float *sum, int *temp)
{
    float num;
    int d;
    
    if (fscanf(f, "%f", &num) == -1)
        return 1;
    
    *sum += num;
    *temp += 1;
    
    while ((d = fscanf(f, "%f", &num)) == 1)
    {
        *sum += num;
        *temp += 1;
    }
    if (d == 0)
        return 2;
        
    return 3;
}

float macking(FILE *f, float equa)
{
    int d;
    float num;
    
    rewind(f);
    
    fscanf(f, "%f", &num);
    float another = fabs(equa - num), answer = num;
    while ((d = fscanf(f, "%f", &num)) == 1)
    {
        if (another > fabs(equa - num))
        {
            another = fabs(equa - num);
            answer = num;
        }
    }
    return answer;
}
