#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int process(FILE *f, int *max_1_res, int *max_2_res);

int main()
{
    int max_1;
    int max_2;
    int d;
    
    d = process(stdin, &max_1, &max_2);
    if (d == -1)
    {
        printf("Incorrect");
        return -1;
    }
    else if (d == -2)
    {
        printf("Incorrect");
        return -1;
    }
    fprintf(stdout, "%d %d", max_1, max_2);

    return 0;
}

int process(FILE *f, int *max_1_res, int *max_2_res)
{
    int x;
    int max_1;
    int max_2;
    int find_max_2 = 0;

    if (fscanf(f, "%d", &x) != 1)
        return -1;
    
    max_1 = x;

    while (fscanf(f, "%d", &x) == 1)
    {
        if (find_max_2 == 0)
        {
            find_max_2 = 1;
            if (x > max_1)
            {
                max_2 = max_1;
                max_1 = x;
            }
            else
                max_2 = x;
        }
        else
        {
            if (x >= max_1)
            {
                max_2 = max_1;
                max_1 = x;
            }
            else if (x > max_2)
                max_2 = x;
        }
    }
    (*max_1_res) = max_1;
    (*max_2_res) = max_2;

    if (find_max_2 == 0)
        return -1;

    return 0;
}
