#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

int getting(int *temp, FILE *fp, long int ind);
int putting(int *temp, FILE *fp, long int ind);
int changing(FILE *fp, long int j, long int j_1);
int macking(char *file_name);
int print(char *file_name);
int rowing(char *file_name);

int main(int argc, char **argv)
{
    srand(time(NULL));

    int answer = -1;

    if (argc == 3)
    {
        if (!strcmp(argv[1], "c"))
            answer = macking(argv[2]);

        if (!strcmp(argv[1], "p"))
            answer = print(argv[2]);

        if (!strcmp(argv[1], "s"))
            answer = rowing(argv[2]);
    }
    else
        answer = -2;

    switch (answer)
    {
        case -1:
            printf("Error");
            break;
        case -2:
            printf("Error");
            break;
        case -3:
            printf("Error");
            break;
        case -7:
            printf("Empty file");
            break;
    }

    return answer;
}

int getting(int *temp, FILE *fp, long int ind)
{
    int temp_1;

    temp_1 = fseek(fp, sizeof(int) * ind, SEEK_SET);
    if (temp_1)
        return -4;

    temp_1 = fread(temp, sizeof(int), 1, fp);
    if (temp_1)
        return 0;

    return -5;
}

int putting(int *temp, FILE *fp, long int ind)
{
    int temp_1;

    temp_1 = fseek(fp, sizeof(int) * ind, SEEK_SET);
    if (temp_1)
        return -4;

    temp_1 = fwrite(temp, sizeof(int), 1, fp);
    if (temp_1)
        return 0;

    return -6;
}

int changing(FILE *fp, long int j, long int j_1)
{
    int temp_j;
    int temp_j_1;

    getting(&temp_j, fp, j);
    getting(&temp_j_1, fp, j_1);

    putting(&temp_j, fp, j_1);
    putting(&temp_j_1, fp, j);

    return 0;
}

int macking(char *file_name)
{
    FILE *fp;

    int n;
    int temp;

    setbuf(stdout, NULL);

    fp = fopen(file_name, "wb");
    if (!fp)
        return -3;

    n = rand() % 10;

    for (long int ind = 0; ind < n; ind ++)
    {
        temp = -1000 + rand() % 2000;
        printf("%d ", temp);
        putting(&temp, fp, ind);
    }

    fclose(fp);
    
    return 0;
}

int print(char *file_name)
{
    FILE *fp;

    int temp_1;
    int temp;
    long int ind = 0;

    setbuf(stdout, NULL);

    fp = fopen(file_name, "rb");
    if (!fp)
        return -3;

    temp_1 = getting(&temp, fp, ind);
    if (temp_1)
    {
        fclose(fp);
        return -7;
    }

    while (!temp_1)
    {
        printf("%d ", temp);
        ind ++;
        temp_1 = getting(&temp, fp, ind);
    }

    fclose(fp);
    return 0;
}

int rowing(char *file_name)
{
    FILE *fp;

    int temp;
    long int n = 0;
    long int i, j;

    int sort_temp_j;
    int sort_temp_j_1;

    fp = fopen(file_name, "rb+wb");
    if (!fp)
        return -3;

    while (!getting(&temp, fp, n))
        n ++;

    if (!n)
    {
        fclose(fp);
        return -7;
    }

    for (i = 0; i < n - 1; i ++)
        for (j = n - 2; j > i - 1; j --)
        {
            getting(&sort_temp_j, fp, j);
            getting(&sort_temp_j_1, fp, j + 1);

            if (sort_temp_j > sort_temp_j_1)
                changing(fp, j, j + 1);
        }

    fclose(fp);
    return 0;
}
