#include <stdio.h>

float avg(int arr[], int n);
int input(int arr[], int *size);

int main()
{
    int n;
    int arr[10];
    int d, *size;
    float check;

    printf("Input size: ");
    d = scanf("%d", &n);

    if (d)
    {
        if ((n > 10) || (n <= 0))
        {
            printf("Incorrect gap");
            return -1;
        }
    }
    else
    {
        printf("Incorrect input");
        return -1;
    }

    size = &n;

    if (input(arr, size))
        return -1;

    check = avg(arr, n);
    if (check == 1)
        return 1;
    else
        printf("Average: %.5f", check);

    return 0;
}

float avg(int arr[], int n)
{
    int sum = 0;
    int count = 0;
    int i = 0;
    while (i < n)
    {
        if (arr[i] < 0)
        {
            sum += arr[i];
            count += 1;
        }
        i += 1;
    }

    if (count == 0)
    {
        printf("No negative numbers");
        return 1;
    }
    else
        return (float)sum / count;
}

int input(int arr[], int *size)
{
    int i = 0;
    int d;
    while ((i < *size))
    {
        printf("Input element: ");
        d = scanf("%d", &arr[i]);
        if (d != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        i += 1;
    }

    return 0;
}
