#include <stdio.h>
#include <math.h>

void print(int arr_1[], int n);
int reverse(int num);
int remake(int arr_1[], int arr_2[], int n);
int input(int arr_1[], int *size);

int main()
{
    int n;
    int arr_1[10], arr_2[10];
    int d, *size;

    printf("Input size: ");
    d = scanf("%d", &n);
    if (d)
    {
        if ((n > 10) || (n <= 0))
        {
            printf("Incorrect gap");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }

    size = &n;
    if (input(arr_1, size))
        return 1;

    d = remake(arr_1, arr_2, n);
    if (d)
    {
        print(arr_2, d);
        return 0;
    }
    else
    {
        printf("No suitable elements");
        return 1;
    }
}

void print(int arr_1[], int n)
{
    printf("New array:\n");

    for (int i = 0; i < n; i++)
        printf("%d ", arr_1[i]);
}

int reverse(int num)
{
    int count = 0;
    int temp = num;
    do
    {
        temp /= 10;
        count += 1;
    } while (temp != 0);
    if (count == 0)
        return -1;
    else
        return num / (int)(pow(10, (count - 1)));
}

int remake(int arr_1[], int arr_2[], int n)
{
    int i = 0, j = 0;
    int temp;
    while (j < n)
    {
        temp = reverse(arr_1[j]);
        if ((temp != -1) && (arr_1[j] % 10) == temp)
        {
            arr_2[i] = arr_1[j];
            i += 1;
        }
        j += 1;
    }

    return i;
}

int input(int arr_1[], int *size)
{
    int i = 0;
    int d;
    while ((i < *size))
    {
        printf("Input element: ");
        d = scanf("%d", &arr_1[i]);
        if (d != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        i += 1;
    }
    return 0;
}
