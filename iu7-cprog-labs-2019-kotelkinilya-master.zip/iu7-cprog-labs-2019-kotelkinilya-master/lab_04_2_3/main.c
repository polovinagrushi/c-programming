#include <stdio.h>
#include <math.h>

int print_arr_1(int *arr_1, int len);
int checking(int num);
int making(int *arr_1, int len, int *arr_2, int *size_2);
int input(int *arr_1, int *len);

int main()
{
    int d;
    int arr_1[10], size_1 = 0;
    int arr_2[10], size_2 = 0;
    d = input(arr_1, &size_1);
    if (d)
    {
        printf("Incorrect input");
        return -1;
    }
    d = making(arr_1, size_1, arr_2, &size_2);
    if (d)
    {
        printf("Incorrect input");
        return -1;
    }
    print_arr_1(arr_2, size_2);
    return 0;
}

int print_arr_1(int *arr_1, int len)
{
    int d = 0;
    printf("New arr_1ay:\n");
    for (int i = 0; i < len; i++)
        printf("%d ", arr_1[i]);
    return d;
}

int checking(int num)
{
    if (num < 0)
        return 0;
    int result = 0;
    int i = 0;
    while (i * i <= num)
    {
        if (i * i == num)
            result = 1;
        i++;
    }
    return result;
}

int making(int *arr_1, int len, int *arr_2, int *size_2)
{
    for (int i = 0; i < len; i++)
        if (!(checking(arr_1[i])))
        {
            arr_2[*size_2] = arr_1[i];
            *size_2 += 1;
        }
    if (*size_2)
        return 0;
    else
        return 1;
}

int input(int *arr_1, int *len)
{
    int d = 0;
    printf("Input size: ");
    d = (scanf("%d", len) == 1) ? 0 : 1;
    if (d)
        return d;
    int i = 0;
    int g;
    while ((i < *len))
    {
        printf("Input element: ");
        g = scanf("%d", &arr_1[i]);
        if (g != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        i += 1;
    }
    return 0;
}
