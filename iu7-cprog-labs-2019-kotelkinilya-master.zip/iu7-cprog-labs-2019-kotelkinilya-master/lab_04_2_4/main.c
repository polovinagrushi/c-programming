#include <stdio.h>
#include <math.h>

int print(int *arr, int len);
int ch_sort(int *arr, int len);
int input(int *arr, int *len);

int main()
{
    int d;
    int arr[10], size = 0;
    d = input(arr, &size);
    if (d)
    {
        printf("Incorrect  input");
        return -1;
    }
    d = ch_sort(arr, size);
    if (d)
    {
        printf("Incorrect input");
        return -1;
    }
    print(arr, size);

    return 0;
}

int print(int *arr, int len)
{
    int d = 0;
    printf("New array:\n");
    for (int i = 0; i < len; i++)
        printf("%d ", arr[i]);

    return d;
}

int ch_sort(int *arr, int len)
{
    for (int i = 0; i < len - 1; i++)
    {
        int key = i + 1;
        int temp = arr[key];
        for (int j = i + 1; j > 0; j--)
        {
            if (temp < arr[j - 1])
            {
                arr[j] = arr[j - 1];
                key = j - 1;
            }
        }
        arr[key] = temp;
    }

    return 0;
}

int input(int *arr, int *len)
{
    int d = 0;
    printf("Input size: ");
    d = (scanf("%d", len) == 1) ? 0 : 1;
    if (d)
        return d;
    int i = 0;
    int g;
    while ((i < *len))
    {
        printf("Input element: ");
        g = scanf("%d", &arr[i]);
        if (g != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        i += 1;
    }
    return 0;
}
