#include <stdio.h>
#include <math.h>

typedef int matrix[10][10];

int alternate(int arr[], int col);
void transpose(matrix arr, int stringg[], int row, int col);
int input(matrix arr, int row, int col);
void transormation(matrix arr, int stringg[], int row, int col);
int print(int stringg[], int n);
int print_matrix(matrix arr, int row, int col);

int main()
{
    int stringg[10];
    int row = 0;
    int col = 0;
    int d;
    matrix arr;
    
    printf("Input number of rows: ");
    d = scanf("%d", &row);
    if (d)
    {
        if ((row > 10) || (row <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }
    
    printf("Input number of columns: ");
    d = scanf("%d", &col);
    if (d)
    {
        if ((col > 10) || (col <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }
    
    d = input(arr, row, col);
    if (d)
        return 1;
    printf("Matrix: \n");
    
    print_matrix(arr, row, col);
    
    transormation(arr, stringg, row, col);
    
    print(stringg, col);
    
    return 0;
}

int alternate(int arr[], int col)
{
    int i;
    
    if (col == 1)
        return 1;
    for (i = 1; i < col; i++)
    {
        if ((arr[i] * arr[i - 1] >= 0) || (arr[i] == 0 && arr[i - 1] == 0))
            return 1;
    }
    
    return 0;
}

void transpose(matrix arr, int stringg[], int row, int col)
{
    int temp = 0;
    int max = 0;
    int min;
    int i;
    int j;
    
    max = (row >= col) ? row : col;
    min = (row >= col) ? col : row;
    
    for (i = 0; i < min; i++)
    {
        for (j = i + 1; j < max; j++)
        {
            temp = arr[i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
}

int input(matrix arr, int row, int col)
{
    int d = 0;
    int count = 0;
    int i;
    int j;
    
    for (i = 0; i < row; i++)
    {
        printf("\nRow %d\n", i + 1);
        count = 0;
        for (j = 0; j < col; j++)
        {
            printf("Input element %d: ", count);
            d = scanf("%d", &arr[i][j]);
            count += 1;
            if (d != 1)
            {
                printf("Incorrect input");
                return 1;
            }
        }
    }
    
    return 0;
}

void transormation(matrix arr, int stringg[], int row, int col)
{
    int i;
    
    transpose(arr, stringg, row, col);
    for (i = 0; i < col; i++)
        if (alternate(arr[i], row))
            stringg[i] = 0;
        else
            stringg[i] = 1;
}

int print(int stringg[], int n)
{
    int count = 0;
    int i;
    
    for (i = 0; i < n; i++)
        if (stringg[i] == 0)
        {
            count += 1;
        }
        else
        {
            printf("\nThe exact column is %d", count);
            count += 1;
        }
        
    return 0;
}

int print_matrix(matrix arr, int row, int col)
{
    int i;
    int j;
    
    for (i = 0; i < row; i++)
    {
        printf("\n");
        for (j = 0; j < col; j++)
            printf(" %3d", arr[i][j]);
    }
    
    return 0;
}
