#include <stdio.h>
#include <math.h>

typedef int matrix[20][10];

int combaining(int num);
int trying(int stringg[], int col);
int input(matrix arr, int row, int col);
int transformation(matrix arr, int row, int col);
int print(matrix arr, int row, int col);

int main()
{
    int row = 0;
    int col = 0;
    int d, temp = 0;
    matrix arr;
    
    printf("Input number of raws: ");
    d = scanf("%d", &row);
    if (d)
    {
        if ((row > 10) || (row <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }
    
    printf("Input number of columns: ");
    d = scanf("%d", &col);
    if (d)
    {
        if ((col > 10) || (col <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }
    
    d = input(arr, row, col);
    if (d)
        return 1;
    printf("Data: \n");
    print(arr, row, col);
    
    temp = transformation(arr, row, col);
    
    printf("Result: \n");
    print(arr, temp, col);
    
    return 0;
}

int combaining(int num)
{
    int combaining = 0;
    while (num != 0)
    {
        combaining = combaining + (num % 10);
        num = num / 10;
    }
    if (combaining % 2)
        return 1;
    else
        return 0;
}
int trying(int stringg[], int col)
{
    int count = 0;
    int i;
    
    for (i = 0; i < col; i++)
    {
        if (combaining(stringg[i]))
            count += 1;
        if (count >= 2)
            return 1;
    }
    
    return 0;
}

int input(matrix arr, int row, int col)
{
    int d = 0;
    int count = 0;
    int i;
    
    for (i = 0; i < row; i++)
    {
        printf("\nRow %d\n", i + 1);
        
        count = 0;
        for (int j = 0; j < col; j++)
        {
            printf("Input element %d: ", count);
            d = scanf("%d", &arr[i][j]);
            count += 1;
            if (d != 1)
            {
                printf("Incorrect input");
                return 1;
            }
        }
    }
    
    return 0;
}
int transformation(matrix arr, int row, int col)
{
    int i;
    int j;
    int k;
    
    for (i = 0; i < row; i++)
    {
        if (trying(arr[i], col))
        {
            for (k = row; k > i; k--)
            {
                for (j = 0; j < col; j++)
                    arr[k][j] = arr[k - 1][j];
            }
            
            for (j = 0; j < col; j++)
                arr[i][j] = -1;
            row = row + 1;
            i++;
        }
    }
    
    return row;
}

int print(matrix arr, int row, int col)
{
    int i;
    int j;
    
    for (i = 0; i < row; i++)
    {
        printf("\n");
        for (j = 0; j < col; j++)
            printf(" %d", arr[i][j]);
    }
    
    return 0;
}
