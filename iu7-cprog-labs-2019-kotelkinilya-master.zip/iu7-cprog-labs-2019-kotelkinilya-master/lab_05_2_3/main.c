#include <stdio.h>
#include <math.h>

typedef int matrix[10][10];

int umnoj(int stringg[], int col);
void sort(matrix arr, int row, int col);
int input(matrix arr, int row, int col);
int print(matrix arr, int row, int col);

int main()
{
    int row = 0;
    int col = 0;
    int d = 0;
    matrix arr;

    printf("Input number of rows: ");
    d = scanf("%d", &row);
    if (d)
    {
        if ((row > 10) || (row <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }

    printf("Input number of columns: ");
    d = scanf("%d", &col);
    if (d)
    {
        if ((col > 10) || (col <= 0))
        {
            printf("Incorrect input");
            return 1;
        }
    }
    else
    {
        printf("Incorrect input");
        return 1;
    }

    d = input(arr, row, col);
    if (d)
        return 1;

    printf("Data: \n");
    print(arr, row, col);

    sort(arr, row, col);

    printf("\n\nResult: ");
    print(arr, row, col);

    return 0;
}

int umnoj(int stringg[], int col)
{
    int temp = 1;
    int i;

    for (i = 0; i < col; i++)
        temp = temp * stringg[i];
    return temp;
}

void sort(matrix arr, int row, int col)
{
    int temp = 0, vrem = 0, try = 0;
    int i;
    int j;

    for (i = 0; i < row; i++)
    {
        vrem = row - 1;
        try = vrem - 1;
        while (try >= 0)
        {
            if (umnoj(arr[vrem], col) < umnoj(arr[try], col))
            {
                for (j = 0; j < col; j++)
                {
                    temp = arr[vrem][j];
                    arr[vrem][j] = arr[try][j];
                    arr[try][j] = temp;
                }
            }
            vrem = try;
            try --;
        }
    }
}

int input(matrix arr, int row, int col)
{
    int d = 0;
    int i;
    int j;

    for (i = 0; i < row; i++)
    {
        printf("\nRow %d\n", i + 1);
        for (j = 0; j < col; j++)
        {
            printf("Input element: ");
            d = scanf("%d", &arr[i][j]);
            if (d != 1)
            {
                printf("Incorrect input");
                return 1;
            }
        }
    }
    return 0;
}

int print(matrix arr, int row, int col)
{
    int i;
    int j;

    for (i = 0; i < row; i++)
    {
        printf("\n");
        for (j = 0; j < col; j++)
            printf(" %d", arr[i][j]);
    }
    return 0;
}
