#include <stdio.h>
#include <string.h>

int selfmade_strcspn(char *strokast, char *strokand);

int main()
{
    char st_str[20] = "0"; //0 //0123456789 //' ' //' ' //1 //absh
    char nd_str[20] = "1";   //1 //6          //' ' // 1 //' '// s

    int my_answer;
    int func_answer;

    printf("1st: %s\n", st_str);
    printf("2nd: %s\n", nd_str);

    func_answer = strcspn(st_str, nd_str);
    printf("Standart: %d\n", func_answer);

    my_answer = selfmade_strcspn(st_str, nd_str);
    printf("My: %d", my_answer);

    return 0;
}

int selfmade_strcspn(char *strokast, char *strokand)
{
    int j = 0;
    int i;
    int answer = 20;

    while (strokand[j] != '\0')
    {
        for (i = 0; strokast[i] != '\0'; i ++)
            if (strokast[i] == strokand[j] && i < answer)
                answer = i;
        j ++;
    }

    if (answer == 20)
        answer = strlen(strokast);
    return answer;
}
