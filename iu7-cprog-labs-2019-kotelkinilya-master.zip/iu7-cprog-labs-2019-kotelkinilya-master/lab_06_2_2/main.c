#include <stdio.h>
#include <string.h>

typedef char matrix[257][17];
typedef char word_t[17];
typedef char stringg[257];

int input(stringg stringg_1, stringg stringg_2);
int creating(stringg str, matrix matrix);
void output(matrix matrix1, int len_1, matrix matrix2, int len_2);

int main()
{
    stringg stringg_1;
    stringg stringg_2;
    int answer;
    answer = input(stringg_1, stringg_2);
    if (answer != 0)
    {
        printf("NULL FILE");
        return -1;
    }
    matrix matrix_1;
    matrix matrix_2;
    int size_of_m1;
    int size_of_m2;
    size_of_m1 = creating(stringg_1, matrix_1);
    size_of_m2 = creating(stringg_2, matrix_2);
    output(matrix_1, size_of_m1, matrix_2, size_of_m2);
    return 0;
}

int input(stringg stringg_1, stringg stringg_2)
{
    int temp;

    printf("1st: ");
    fgets(stringg_1, 257, stdin);
    temp = strcspn(stringg_1, "\n");

    if (!temp)
        return -1;
    stringg_1[temp] = '\0';

    printf("2nd: ");
    fgets(stringg_2, 257, stdin);
    temp = strcspn(stringg_2, "\n");

    if (!temp)
        return -1;
    stringg_2[temp] = '\0';

    return 0;
}

int creating(stringg str, matrix matrix)
{
    int p = 0;
    int size_of_mt = 0;
    int count = 0;
    word_t word;

    for (int i = 0; i < strlen(str); i ++)
        if ((str[i] == ';' || str[i] == ':') || (str[i] == ' ' || str[i] == '-') || (str[i] == ',' || str[i] == '.') || (str[i] == '!' || str[i] == '?') )
        {
            if (p != 0)
            {
                word[p] = '\0';
                strcpy(matrix[count], word);
                p = 0;
                count ++;
                size_of_mt ++;
            }
        }
        else
        {
            word[p] = str[i];
            p ++;
        }
    if (p != 0)
    {
        word[p] = '\0';
        strcpy(matrix[count], word);
        size_of_mt ++;
    }

    if (size_of_mt == 0)
    {
        printf("String is empty.");
        return -1;
    }

    return size_of_mt;
}

void output(matrix matrix1, int len_1, matrix matrix2, int len_2)
{
    int d;
    int arr[17];

    for (int i = 0; i < len_1; i ++)
    {
        d = 0;
        for (int j = 0; j < len_2; j ++)
            if (strcmp(matrix1[i], matrix2[j]) == 0)
                d ++;
        if (d > 0)
            arr[i] = 1;
        else
            arr[i] = 0;
    }

    for (int i = 0; i < len_1; i ++)
        if (arr[i])
            printf("%s is in the 2nd string\n", matrix1[i]);
        else
            printf("%s is not in the 2nd string\n", matrix1[i]);
}
