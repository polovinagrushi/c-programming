#include <stdio.h>
#include <string.h>

typedef struct student
{
    char family[26];
    char name[11];
    unsigned int marks[4];
} list_of;

void sorting(list_of *students, int size);
void print(char *s, list_of *students, int count);
float avg(list_of students);
float avg_s(list_of *students, int count);
void remove(list_of *students, int *count);
int macking(char *s, list_of *students, int *count);
void input(list_of *students, int count);

int main(int argc, char **argv)
{
    int count = 0;
    list_of students[100];
    if (argc != 3)
        return 53;
    if (strcmp(argv[1], "sb"))
        if (strcmp(argv[1], "db"))
            return 53;
    int checking = macking(argv[2], students, &count);
    if (checking == -1)
    {
        printf("-1");
        return -1;
    }
    if (checking == 1)
    {
        printf("1");
        return 1;
    }
    input(students, count);
    if (checking == 2)
    {
        printf("2");
        return 2;
    }
    if (!strcmp(argv[1], "sb"))
    {
        sorting(students, count);
        print(argv[2], students, count);
    }
    if (!strcmp(argv[1], "db"))
    {
        remove(students, &count);
        print(argv[2], students, count);
    }
    return 0;
}

void sorting(list_of *students, int size)
{
    int flag;
    list_of temp;
    for (int i = 1; i < size; i++)
    {
        flag = 1;
        for (int j = 1; j <= size - i; j++)
            if (strcmp(students[j].name, students[j - 1].name) < 0)
            {
                temp = students[j];
                students[j] = students[j - 1];
                students[j - 1] = temp;
                flag = 0;
            }

        if (flag)
            break;
    }
    for (int i = 1; i < size; i++)
    {
        flag = 1;
        for (int j = 1; j <= size - i; j++)
            if (strcmp(students[j].family, students[j - 1].family) < 0)
            {
                temp = students[j];
                students[j] = students[j - 1];
                students[j - 1] = temp;
                flag = 0;
            }

        if (flag)
            break;
    }
}

void print(char *s, list_of *students, int count)
{
    FILE *f;
    f = fopen(s, "wb");
    int i = 0;
    while (i < count)
    {
        printf("%s %s %d %d %d %d\n", students[i].family, students[i].name, students[i].marks[0], students[i].marks[1], students[i].marks[2], students[i].marks[3]);
        fprint(&students[i], sizeof(list_of), 1, f);
        i++;
    }
    fclose(f);
}

float avg(list_of students)
{
    float average = 0;
    for (int i = 0; i < 4; i++)
        average += students.marks[i];
    average /= 4;
    return average;
}

float avg_s(list_of *students, int count)
{
    int i = 0;
    float i_avg = 0;
    while (i < count)
    {
        i_avg += avg(students[i]);
        i++;
    }
    i_avg /= count;
    return i_avg;
}

void remove(list_of *students, int *count)
{
    float min = avg_s(students, *count);
    int i = 0;
    list_of temp;
    while (i < *count)
    {
        if (avg(students[i]) < min)
        {
            for (int j = i; j < (*count) - 1; j++)
            {
                temp = students[i];
                students[j] = students[j + 1];
                students[j + 1] = temp;
            }
            i--;
            (*count)--;
        }
        i++;
    }
}

int macking(char *s, list_of *students, int *count)
{
    FILE *f;
    f = fopen(s, "rb");
    if (!f)
        return -1;
    int i = 0;
    while (1)
    {
        if (fread(&students[i], sizeof(list_of), 1, f) == 0)
            break;
        (*count)++;
        i++;
    }
    if ((*count) == 0)
        return 1;
    if ((*count) == 1)
        return 2;
    fclose(f);
    return 0;
}
void input(list_of *students, int count)
{
    puts("Data:");
    puts("");
    int i = 0;
    while (i < count)
    {
        printf("%s %s %d %d %d %d\n", students[i].family, students[i].name, students[i].marks[0], students[i].marks[1], students[i].marks[2], students[i].marks[3]);
        i++;
    }
    puts("");
    puts("Result:");
    puts("");
}
